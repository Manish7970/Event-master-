import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { WebSocket, WebSocketServer } from "ws";
import { insertEventSchema } from "@shared/schema";

export function registerRoutes(app: Express): Server {
  setupAuth(app);

  const httpServer = createServer(app);
  const wss = new WebSocketServer({ 
    server: httpServer,
    path: "/ws"
  });

  wss.on('connection', (ws) => {
    console.log('WebSocket client connected');

    ws.on('error', console.error);

    ws.on('close', () => {
      console.log('WebSocket client disconnected');
    });
  });

  function broadcastEventUpdate() {
    wss.clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send("event_update");
      }
    });
  }

  app.get("/api/events", async (req, res) => {
    try {
      const events = await storage.getEvents();
      res.json(events);
    } catch (error) {
      console.error('Error fetching events:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get("/api/events/:id", async (req, res) => {
    try {
      const event = await storage.getEvent(parseInt(req.params.id));
      if (!event) return res.status(404).json({ message: 'Event not found' });
      res.json(event);
    } catch (error) {
      console.error('Error fetching event:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post("/api/events", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const parseResult = insertEventSchema.safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }

      const event = await storage.createEvent(parseResult.data, req.user.id);
      broadcastEventUpdate();
      res.status(201).json(event);
    } catch (error) {
      console.error('Error creating event:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.patch("/api/events/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const event = await storage.getEvent(parseInt(req.params.id));
      if (!event) return res.status(404).json({ message: 'Event not found' });
      if (event.userId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });

      const parseResult = insertEventSchema.partial().safeParse(req.body);
      if (!parseResult.success) {
        return res.status(400).json(parseResult.error);
      }

      const updatedEvent = await storage.updateEvent(parseInt(req.params.id), parseResult.data);
      broadcastEventUpdate();
      res.json(updatedEvent);
    } catch (error) {
      console.error('Error updating event:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.delete("/api/events/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const event = await storage.getEvent(parseInt(req.params.id));
      if (!event) return res.status(404).json({ message: 'Event not found' });
      if (event.userId !== req.user.id) return res.status(403).json({ message: 'Forbidden' });

      await storage.deleteEvent(parseInt(req.params.id));
      broadcastEventUpdate();
      res.sendStatus(204);
    } catch (error) {
      console.error('Error deleting event:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.get("/api/events/:id/attendees", async (req, res) => {
    try {
      const attendees = await storage.getEventAttendees(parseInt(req.params.id));
      res.json(attendees);
    } catch (error) {
      console.error('Error fetching attendees:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.post("/api/events/:id/attendees", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const event = await storage.getEvent(parseInt(req.params.id));
      if (!event) return res.status(404).json({ message: 'Event not found' });

      const attendees = await storage.getEventAttendees(parseInt(req.params.id));
      if (attendees.length >= event.maxAttendees) {
        return res.status(400).json({ message: 'Event is full' });
      }

      const attendee = await storage.addAttendee(parseInt(req.params.id), req.user.id);
      broadcastEventUpdate();
      res.status(201).json(attendee);
    } catch (error) {
      console.error('Error adding attendee:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  app.delete("/api/events/:id/attendees", async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: 'Unauthorized' });

    try {
      const event = await storage.getEvent(parseInt(req.params.id));
      if (!event) return res.status(404).json({ message: 'Event not found' });

      await storage.removeAttendee(parseInt(req.params.id), req.user.id);
      broadcastEventUpdate();
      res.sendStatus(204);
    } catch (error) {
      console.error('Error removing attendee:', error);
      res.status(500).json({ message: 'Internal server error' });
    }
  });

  return httpServer;
}