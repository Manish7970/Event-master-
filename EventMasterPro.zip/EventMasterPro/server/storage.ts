import { InsertUser, User, Event, InsertEvent, Attendee } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getEvents(): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent, userId: number): Promise<Event>;
  updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined>;
  deleteEvent(id: number): Promise<void>;

  getEventAttendees(eventId: number): Promise<Attendee[]>;
  addAttendee(eventId: number, userId: number): Promise<Attendee>;
  removeAttendee(eventId: number, userId: number): Promise<void>;

  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private events: Map<number, Event>;
  private attendees: Map<number, Attendee>;
  private currentUserId: number;
  private currentEventId: number;
  private currentAttendeeId: number;
  readonly sessionStore: session.Store;

  constructor() {
    this.users = new Map();
    this.events = new Map();
    this.attendees = new Map();
    this.currentUserId = 1;
    this.currentEventId = 1;
    this.currentAttendeeId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000,
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getEvents(): Promise<Event[]> {
    return Array.from(this.events.values());
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(event: InsertEvent, userId: number): Promise<Event> {
    const id = this.currentEventId++;
    const newEvent: Event = { ...event, id, userId };
    this.events.set(id, newEvent);
    return newEvent;
  }

  async updateEvent(id: number, event: Partial<InsertEvent>): Promise<Event | undefined> {
    const existingEvent = this.events.get(id);
    if (!existingEvent) return undefined;

    const updatedEvent = { ...existingEvent, ...event };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }

  async deleteEvent(id: number): Promise<void> {
    this.events.delete(id);
    // Delete associated attendees
    const attendeesToDelete = Array.from(this.attendees.entries())
      .filter(([_, attendee]) => attendee.eventId === id);

    for (const [id] of attendeesToDelete) {
      this.attendees.delete(id);
    }
  }

  async getEventAttendees(eventId: number): Promise<Attendee[]> {
    return Array.from(this.attendees.values()).filter(
      (attendee) => attendee.eventId === eventId
    );
  }

  async addAttendee(eventId: number, userId: number): Promise<Attendee> {
    const id = this.currentAttendeeId++;
    const attendee: Attendee = { id, eventId, userId };
    this.attendees.set(id, attendee);
    return attendee;
  }

  async removeAttendee(eventId: number, userId: number): Promise<void> {
    const attendeeEntry = Array.from(this.attendees.entries())
      .find(([_, a]) => a.eventId === eventId && a.userId === userId);

    if (attendeeEntry) {
      this.attendees.delete(attendeeEntry[0]);
    }
  }
}

export const storage = new MemStorage();