import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { CalendarDays, MapPin, Users, Plus, Search, Loader2 } from "lucide-react";
import { useEffect, useState } from "react";
import { format, isBefore, isAfter } from "date-fns";
import { Event, Attendee } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

// Stock event photos
const EVENT_PHOTOS = [
  "https://images.unsplash.com/photo-1491438590914-bc09fcaaf77a",
  "https://images.unsplash.com/photo-1508657594088-375f2f60c581",
  "https://images.unsplash.com/photo-1455849318743-b2233052fcff",
  "https://images.unsplash.com/photo-1550177977-ad69e8f3cae0"
];

export default function HomePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [timeFilter, setTimeFilter] = useState<"all" | "upcoming" | "past">("all");

  const { data: events = [], isLoading } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  const { data: attendeesMap = {} } = useQuery<Record<number, Attendee[]>>({
    queryKey: ["/api/attendees"],
    queryFn: async () => {
      const attendeesPromises = events.map(event =>
        fetch(`/api/events/${event.id}/attendees`).then(res => res.json())
      );
      const attendeesList = await Promise.all(attendeesPromises);
      return events.reduce((acc, event, index) => {
        acc[event.id] = attendeesList[index];
        return acc;
      }, {} as Record<number, Attendee[]>);
    },
    enabled: events.length > 0,
  });

  const joinEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      const res = await apiRequest("POST", `/api/events/${eventId}/attendees`);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/attendees"] });
      toast({
        title: "Success",
        description: "You have joined the event!",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const websocket = new WebSocket(`${protocol}//${window.location.host}/ws`);

    websocket.onopen = () => {
      console.log('WebSocket connected');
    };

    websocket.onmessage = (event) => {
      if (event.data === "event_update") {
        queryClient.invalidateQueries({ queryKey: ["/api/events"] });
        queryClient.invalidateQueries({ queryKey: ["/api/attendees"] });
      }
    };

    websocket.onerror = (error) => {
      console.error('WebSocket error:', error);
    };

    return () => {
      if (websocket.readyState === WebSocket.OPEN) {
        websocket.close();
      }
    };
  }, []);

  const filteredEvents = events.filter(event => {
    const matchesSearch = 
      event.title.toLowerCase().includes(search.toLowerCase()) ||
      event.description.toLowerCase().includes(search.toLowerCase()) ||
      event.location.toLowerCase().includes(search.toLowerCase());

    const eventDate = new Date(event.date);
    const now = new Date();

    if (timeFilter === "upcoming") {
      return matchesSearch && isAfter(eventDate, now);
    } else if (timeFilter === "past") {
      return matchesSearch && isBefore(eventDate, now);
    }

    return matchesSearch;
  });

  const isAttending = (eventId: number) => {
    return attendeesMap[eventId]?.some(attendee => attendee.userId === user?.id);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="text-4xl font-bold mb-2">Welcome, {user?.username}!</h1>
            <p className="text-muted-foreground">Discover and join amazing events</p>
          </div>
          <Link href="/create-event">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Create Event
            </Button>
          </Link>
        </div>

        <div className="flex gap-4 mb-6">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search events..."
                className="pl-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>
          <Select value={timeFilter} onValueChange={(value: "all" | "upcoming" | "past") => setTimeFilter(value)}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Filter by time" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Events</SelectItem>
              <SelectItem value="upcoming">Upcoming Events</SelectItem>
              <SelectItem value="past">Past Events</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {isLoading ? (
          <div className="flex justify-center items-center h-64">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : filteredEvents.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No events found</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredEvents.map((event, index) => (
              <Card key={event.id} className="overflow-hidden">
                <img
                  src={EVENT_PHOTOS[index % EVENT_PHOTOS.length]}
                  alt={event.title}
                  className="w-full h-48 object-cover"
                />
                <CardHeader>
                  <CardTitle className="line-clamp-1">{event.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground line-clamp-2 mb-4">
                    {event.description}
                  </p>
                  <div className="space-y-2">
                    <div className="flex items-center text-sm">
                      <CalendarDays className="mr-2 h-4 w-4" />
                      {format(new Date(event.date), "PPP")}
                    </div>
                    <div className="flex items-center text-sm">
                      <MapPin className="mr-2 h-4 w-4" />
                      {event.location}
                    </div>
                    <div className="flex items-center text-sm">
                      <Users className="mr-2 h-4 w-4" />
                      {(attendeesMap[event.id]?.length || 0)} / {event.maxAttendees} spots
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button 
                    className="w-full" 
                    disabled={isAttending(event.id) || joinEventMutation.isPending}
                    onClick={() => joinEventMutation.mutate(event.id)}
                  >
                    {joinEventMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                    {isAttending(event.id) ? 'Already Joined' : 'Join Event'}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}