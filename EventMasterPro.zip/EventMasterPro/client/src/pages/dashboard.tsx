import { useAuth } from "@/hooks/use-auth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CalendarDays, Users, Activity, Calendar, Pencil, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { Event, Attendee } from "@shared/schema";
import { EditEventDialog } from "@/components/edit-event-dialog";
import { useState } from "react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function DashboardPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [editingEvent, setEditingEvent] = useState<Event | null>(null);

  // Fetch all events
  const { data: events = [] } = useQuery<Event[]>({
    queryKey: ["/api/events"],
  });

  // Fetch attendees for all events
  const { data: attendeesMap = {} } = useQuery<Record<number, Attendee[]>>({
    queryKey: ["/api/attendees"],
    queryFn: async () => {
      const attendeesPromises = events.map(event =>
        fetch(`/api/events/${event.id}/attendees`).then(res => res.json())
      );
      const attendeesList = await Promise.all(attendeesPromises);
      return events.reduce((acc, event, index) => {
        acc[event.id] = attendeesList[index];
        return acc;
      }, {} as Record<number, Attendee[]>);
    },
    enabled: events.length > 0,
  });

  const deleteEventMutation = useMutation({
    mutationFn: async (eventId: number) => {
      await apiRequest("DELETE", `/api/events/${eventId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/events"] });
      toast({
        title: "Event deleted",
        description: "Your event has been deleted successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete event",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Filter events created by the user
  const createdEvents = events.filter(event => event.userId === user?.id);

  // Filter events the user is attending
  const attendingEvents = events.filter(event =>
    attendeesMap[event.id]?.some(attendee => attendee.userId === user?.id)
  );

  // Calculate statistics
  const totalAttendees = createdEvents.reduce((total, event) =>
    total + (attendeesMap[event.id]?.length || 0), 0
  );

  const upcomingEvents = attendingEvents.filter(event =>
    new Date(event.date) > new Date()
  ).length;

  return (
    <div className="min-h-screen bg-background">
      <div className="container mx-auto p-6">
        <h1 className="text-4xl font-bold mb-8">Dashboard</h1>

        {/* Stats Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="flex items-center pt-6">
              <Calendar className="h-8 w-8 text-primary mr-4" />
              <div>
                <p className="text-sm font-medium">Created Events</p>
                <h3 className="text-2xl font-bold">{createdEvents.length}</h3>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center pt-6">
              <Users className="h-8 w-8 text-primary mr-4" />
              <div>
                <p className="text-sm font-medium">Total Attendees</p>
                <h3 className="text-2xl font-bold">{totalAttendees}</h3>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center pt-6">
              <Activity className="h-8 w-8 text-primary mr-4" />
              <div>
                <p className="text-sm font-medium">Attending</p>
                <h3 className="text-2xl font-bold">{attendingEvents.length}</h3>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="flex items-center pt-6">
              <CalendarDays className="h-8 w-8 text-primary mr-4" />
              <div>
                <p className="text-sm font-medium">Upcoming Events</p>
                <h3 className="text-2xl font-bold">{upcomingEvents}</h3>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Events Lists */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Created Events */}
          <Card>
            <CardHeader>
              <CardTitle>Events You Created</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {createdEvents.length === 0 ? (
                  <p className="text-muted-foreground">No events created yet.</p>
                ) : (
                  createdEvents.map(event => (
                    <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{event.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(event.date), "PPP")}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex items-center text-sm text-muted-foreground mr-4">
                          <Users className="h-4 w-4 mr-1" />
                          {attendeesMap[event.id]?.length || 0} / {event.maxAttendees}
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setEditingEvent(event)}
                        >
                          <Pencil className="h-4 w-4" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => {
                            if (confirm('Are you sure you want to delete this event?')) {
                              deleteEventMutation.mutate(event.id);
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>

          {/* Attending Events */}
          <Card>
            <CardHeader>
              <CardTitle>Events You're Attending</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {attendingEvents.length === 0 ? (
                  <p className="text-muted-foreground">Not attending any events yet.</p>
                ) : (
                  attendingEvents.map(event => (
                    <div key={event.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h4 className="font-medium">{event.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {format(new Date(event.date), "PPP")}
                        </p>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {event.location}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {editingEvent && (
        <EditEventDialog
          event={editingEvent}
          open={true}
          onOpenChange={(open) => {
            if (!open) setEditingEvent(null);
          }}
        />
      )}
    </div>
  );
}