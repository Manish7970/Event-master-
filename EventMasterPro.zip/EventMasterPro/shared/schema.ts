import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  date: timestamp("date").notNull(),
  location: text("location").notNull(),
  imageUrl: text("image_url").notNull(),
  userId: integer("user_id").notNull(),
  maxAttendees: integer("max_attendees").notNull(),
});

export const attendees = pgTable("attendees", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  eventId: integer("event_id").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
}).extend({
  password: z.string().min(6, "Password must be at least 6 characters")
});

export const insertEventSchema = createInsertSchema(events).omit({
  id: true,
  userId: true,
}).extend({
  date: z.string().transform((str) => new Date(str)),
  maxAttendees: z.number().min(1, "Must allow at least 1 attendee"),
  title: z.string().min(1, "Title is required"),
  description: z.string().min(1, "Description is required"),
  location: z.string().min(1, "Location is required"),
});

export const insertAttendeeSchema = createInsertSchema(attendees).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type InsertAttendee = z.infer<typeof insertAttendeeSchema>;

export type User = typeof users.$inferSelect;
export type Event = typeof events.$inferSelect;
export type Attendee = typeof attendees.$inferSelect;